import io
import os
import re
from datetime import datetime
import pymongo
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from bson import ObjectId
from flask import Flask, request, render_template, redirect, session, jsonify,make_response

import  requests

APP_ROUTE=os.path.dirname(os.path.abspath(__file__))
PROFILES_PATH=APP_ROUTE+"/static/profiles"

app=Flask(__name__)
app.secret_key="Student_Internship_Portal"


my_client=pymongo.MongoClient("mongodb://localhost:27017")
my_database=my_client["Internship"]
admin_collection=my_database["admin"]
employer_collection=my_database["employer"]
student_collection=my_database["students"]
internship_collection=my_database["internships"]
application_collection = my_database["applications"]
shortlist_collection= my_database["shortlists"]

admin_username = "admin"
admin_password = "admin"


count = admin_collection.count_documents({"username": admin_username,"password": admin_password})

if count == 0:
    admin_collection.insert_one({ "username": admin_username,"password": admin_password})



@app.route("/chat_interface")
def chat_interface():
    return render_template("chat_interface.html")


resume_state = {}  # global resume progress


def extract_title_or_role(msg):
    """
    Extracts internship title or role from free-form messages.
    Works for queries like:
    - 'Who offers Python Developer?'
    - 'Tell me about Backend Developer internship'
    """
    msg = msg.lower().replace("?", "").replace(".", "")

    # Remove common stop words
    stop_words = ["who", "offers", "offer", "internship", "intern", "position", "role", "tell", "me", "about", "the",
                  "for"]
    words = [w for w in msg.split() if w not in stop_words]

    if not words:
        return None

    # Return the remaining words as title (title case)
    return " ".join(words).title()

# -------------------- MAIN CHAT ROUTE --------------------
@app.route("/intern_chat", methods=["POST"])
def intern_chat():
    raw_message = request.json.get("message", "")
    lower_message = raw_message.lower()

    # ---------------- SESSION CHECK ----------------
    student_id = session.get("student_id")
    if not student_id:
        return jsonify({"reply": "Please log in as a student to continue."})

    student_id = ObjectId(student_id)
    user_id = str(student_id)

    # ---------------- RESUME QUESTIONS ----------------
    RESUME_QUESTIONS = {
        1: "Great! What's your <b>full name</b>?",
        2: "Enter your <b>Email</b>:",
        3: "Enter your <b>Phone Number</b>:",
        4: "Write a short <b>Career Objective</b>:",
        5: "List your <b>Skills</b> (comma separated):",
        6: "Enter your <b>Education</b>:",
        7: "List your <b>Certifications</b>:",
        8: "Describe your <b>Projects</b>:",
        9: "Describe your <b>Experience</b>:",
        10: "List your <b>Achievements</b>:",
        11: "Languages you know:",
        12: "Enter your <b>Address</b>:"
    }

    # ---------------- RESUME FLOW HANDLING ----------------
    if user_id in resume_state:
        step = resume_state[user_id]["step"]
        resume_state[user_id]["answers"].append(raw_message)

        if step == 12:
            data = resume_state[user_id]["answers"]
            html_resume = build_resume_template(data)
            session["resume_html"] = html_resume
            del resume_state[user_id]

            return jsonify({
                "reply": "<b>Your Resume is Ready! 🎉</b><br><br>" +
                         html_resume +
                         "<br><br><a href='/download_resume' class='download-btn' "
                         "style='padding:10px 15px;background:#3498db;color:white;border-radius:6px;text-decoration:none;'>"
                         "⬇ Download Resume (PDF)</a>"
            })

        resume_state[user_id]["step"] += 1
        next_step = resume_state[user_id]["step"]
        return jsonify({"reply": RESUME_QUESTIONS[next_step]})

    # ---------------- INTENT DETECTION ----------------
    intent = detect_intern_intent(lower_message)
    slots = extract_intern_slots(raw_message)

    company_name = slots.get("company_name", "").strip()
    internship_title = slots.get("internship_title", "").strip()
    skill_name = slots.get("skill_name", "").strip()

    # ---------------- INTENT HANDLERS ----------------

    # SHOW MY INTERNSHIPS
    if intent == "SHOW_MY_INTERNSHIPS":
        apps = list(application_collection.find({"student_id": student_id}))
        if not apps:
            return jsonify({"reply": "You have not applied to any internships yet."})

        reply = "<b>Your Internships:</b><br>"
        for a in apps:
            intern = internship_collection.find_one({"_id": a["internship_id"]})
            if intern:
                reply += f"• {intern['title']} (Status: {a['status']})<br>"
        return jsonify({"reply": reply})

    # INTERNSHIP DETAILS
    if intent == "INTERNSHIP_DETAILS":
        title = internship_title or _fallback_after_keyword(raw_message, lower_message, ["details of", "internship", "role"])
        rec = internship_collection.find_one({"title": {"$regex": f"^{title}$", "$options": "i"}})
        if not rec:
            return jsonify({"reply": f"No internship found with title '{title}'."})
        return jsonify({"reply": f"<b>{rec['title']}</b><br>Role: {rec['role']}<br>Status: {rec['status']}<br>Description: {rec['description']}"})

    # WHO OFFERS INTERNSHIP
    if intent == "WHO_OFFERS_INTERNSHIP":
        # Try slot first
        title = internship_title.strip() if internship_title else None

        # Fallback: extract from free-form message
        if not title:
            title = extract_title_or_role(raw_message)

        if not title:
            return jsonify({"reply": "Please tell me the internship title."})

        # Search internships (case-insensitive)
        recs = list(internship_collection.find({
            "$or": [
                {"title": {"$regex": re.escape(title), "$options": "i"}},
                {"role": {"$regex": re.escape(title), "$options": "i"}}
            ]
        }))

        if not recs:
            return jsonify({"reply": f"No company currently offers '{title}'."})

        reply = f"<b>Companies offering '{title}' internships:</b><br>"
        for r in recs:
            try:
                employer = employer_collection.find_one({"_id": ObjectId(r['employer_id'])})
                company = employer['company_name'] if employer else "Unknown company"
            except:
                company = "Unknown company"
            reply += f"• {company} (Status: {r['status']})<br>"

        return jsonify({"reply": reply})

    # INTERNSHIPS BY COMPANY
    if intent == "INTERNSHIPS_BY_COMPANY":
        # 1. Extract company name safely
        name = company_name or extract_company_safely(raw_message)
        print(name)

        if not name:
            return jsonify({"reply": "Please provide the company name."})

        # Keep the original casing, Mongo $regex "i" handles case-insensitive search
        employer = employer_collection.find_one({ "$or": [
                {"company_name": {"$regex": re.escape(name), "$options": "i"}},

            ]})
        print(employer)
        recs = list(internship_collection.find({'employer_id':ObjectId(employer['_id'])}))


        if not recs:
            return jsonify({"reply": f"No internships found for company '{name}'."})

        reply = f"<b>Internships at {name}:</b><br>"
        for r in recs:
            reply += f"• {r['title']} ({r['status']})<br>"
        return jsonify({"reply": reply})

    # SKILL MATCH INTERNSHIPS
    if intent == "SKILL_MATCH_INTERNSHIPS":
        # Extract skill(s) from slots or message
        skill_text = skill_name or _fallback_after_keyword(raw_message, lower_message, ["skill", "skills", "for"])
        if not skill_text:
            return jsonify({"reply": "Please mention a skill."})

        # Split multiple skills (comma, 'and', or space)
        skills = [s.strip().lower() for s in re.split(r',|and', skill_text)]

        # Search internships matching any of the skills
        recs = []
        for intern in internship_collection.find():
            intern_text = (intern.get("description", "") + " " + intern.get("role", "")).lower()
            if any(skill in intern_text for skill in skills):
                recs.append(intern)

        if not recs:
            return jsonify({"reply": f"No internships require the skill(s) '{skill_text}'."})

        # Build HTML reply
        reply = f"<b>Internships requiring '{skill_text}':</b><br>"
        for r in recs:
            reply += f"• {r.get('title', 'Unknown Title')} (Role: {r.get('role', 'N/A')})<br>"

        return jsonify({"reply": reply})

    # RECOMMEND BY SKILLS
    if intent == "RECOMMEND_BY_SKILLS":
        skills = extract_skills_from_message(raw_message)
        if not skills:
            return jsonify({"reply": "Please mention your skills to get recommendations."})
        recs = []
        for intern in internship_collection.find():
            matched = [s for s in skills if s.lower() in intern["description"].lower() or s.lower() in intern["role"].lower()]
            if matched:
                recs.append((intern, matched))
        if not recs:
            return jsonify({"reply": "No internships match your skills currently."})
        reply = "<b>Recommended Internships for you:</b><br>"
        for r, matched in recs:
            reply += f"• {r['title']} at employer {r['employer_id']} (Matches: {', '.join(matched)})<br>"
        return jsonify({"reply": reply})

    # RESUME FLOW
    if intent == "RESUME_FLOW":
        resume_state[user_id] = {"step": 1, "answers": []}
        return jsonify({"reply": RESUME_QUESTIONS[1]})

    # COVER LETTER HELP
    if intent == "COVER_LETTER_HELP":
        cover_letter = generate_cover_letter(raw_message)
        return jsonify({"reply": "<b>Your cover letter draft:</b><br>" + cover_letter})

    # APPLICATION STATUS
    if intent == "APPLICATION_STATUS":
        apps = list(application_collection.find({"student_id": student_id}))
        if not apps:
            return jsonify({"reply": "You have not applied for any internships."})
        reply = "<h3>Your Applications</h3>"
        for a in apps:
            intn = internship_collection.find_one({"_id": a["Internship_id"]})
            reply += f"<b>{intn['title']}</b> — {a['Status']}<br>"
        return jsonify({"reply": reply})

    # FIND ALL INTERNSHIPS
    if intent == "FIND_INTERNSHIP":
        recs = list(internship_collection.find())
        if not recs:
            return jsonify({"reply": "No internships available right now."})
        reply = "<b>Available Internships:</b><br>"
        for r in recs:
            reply += f"• {r['title']} at {r['company_name']}<br>"
        return jsonify({"reply": reply})

    # GREETING
    if intent == "GREETING":
        return jsonify({"reply": "Hello 👋! Ask me about internships, skills, companies, or resume writing!"})

    return jsonify({"reply": "Sorry, I didn’t understand that. Try asking about internships or resume help."})

# -------------------- INTENT DETECTION --------------------
def detect_intern_intent(message):
    msg = message.lower()
    # GREETING with word boundary
    if re.search(r"\b(hi|hello|hey)\b", msg):
        return "GREETING"
    if "my internships" in msg or "show my internships" in msg:
        return "SHOW_MY_INTERNSHIPS"
    if "application status" in msg or ("status" in msg and "application" in msg):
        return "APPLICATION_STATUS"
    if "internships by " in msg or "show internships by " in msg or "internships at " in msg or msg.startswith("internships by"):
        return "INTERNSHIPS_BY_COMPANY"
    if "who offers" in msg or "who offer" in msg:
        return "WHO_OFFERS_INTERNSHIP"
    if "details of" in msg or "internship details" in msg:
        return "INTERNSHIP_DETAILS"
    if any(k in msg for k in ["skill", "skills", "for"]):
        return "SKILL_MATCH_INTERNSHIPS"

    if "recommend internships" in msg or "recommend by skills" in msg:
        return "RECOMMEND_BY_SKILLS"
    # resume
    if any(kw in msg for kw in ["build my resume", "create my resume", "resume help", "resume template"]):
        return "RESUME_FLOW"
    # fallback LLM
    prompt = f"""
    You are an intent classifier for an Internship Assistant.
    Choose ONE intent only:
    SHOW_MY_INTERNSHIPS
    INTERNSHIP_DETAILS
    WHO_OFFERS_INTERNSHIP
    INTERNSHIPS_BY_COMPANY
    SKILL_MATCH_INTERNSHIPS
    RECOMMEND_BY_SKILLS
    RESUME_FLOW
    COVER_LETTER_HELP
    APPLICATION_STATUS
    FIND_INTERNSHIP
    GREETING
    UNKNOWN
    Message: "{message}"
    Return ONLY the intent name.
    """
    res = requests.post("http://localhost:11434/api/generate",
                        json={"model": "llama3", "prompt": prompt, "stream": False})
    return res.json()["response"].strip().upper()


# -------------------- SLOT EXTRACTION --------------------
def extract_company_safely(msg):
    # Match "by GVS", "at GVS", "internships at GVS"
    m = re.search(r"(?:internships|show internships)?\s*(?:by|at)\s+([a-zA-Z0-9 &.\-]+)", msg, re.IGNORECASE)
    if m:
        return m.group(1).strip()
    # fallback
    m2 = re.search(r"(?:by|at|from)\s+([a-zA-Z0-9 &.\-]+)", msg, re.IGNORECASE)
    if m2:
        return m2.group(1).strip()
    return ""

def extract_title_safely(msg):
    m = re.search(r"(?:details of|role|internship|position)\s+(.*)", msg, re.IGNORECASE)
    if m:
        return m.group(1).strip().title()
    return ""

def extract_skill_safely(msg):
    m = re.search(r"(?:skill|skills|for)\s+([a-z0-9 ,]+)", msg, re.IGNORECASE)
    if m:
        return m.group(1).strip().title()
    return ""

def extract_intern_slots(msg):
    return {
        "company_name": extract_company_safely(msg),
        "internship_title": extract_title_safely(msg),
        "skill_name": extract_skill_safely(msg)
    }

def _fallback_after_keyword(raw, lower, keywords):
    for w in keywords:
        if w in lower:
            return raw.lower().split(w, 1)[1].strip().title()
    return ""

# -------------------- LLM HELPER --------------------
def extract_skills_from_message(msg):
    prompt = f"Extract all skills mentioned in this message: '{msg}'. Return as a Python list of strings."
    res = requests.post("http://localhost:11434/api/generate",
                        json={"model": "llama3", "prompt": prompt, "stream": False})
    try:
        skills = eval(res.json()["response"].strip())
        return skills if isinstance(skills, list) else []
    except:
        return []

def build_resume_template(data):
    return f"""
    <div style='font-family: Arial, sans-serif; padding: 20px; line-height: 1.6; border: 2px solid #ddd; border-radius: 10px; background: #fdfdfd;'>

        <!-- Header Section -->
        <h2 style='color: #2c3e50; margin-bottom: 5px;'>{data[0]}</h2>
        <p style='margin: 0;'><b>Email:</b> {data[1]}</p>
        <p style='margin: 0;'><b>Phone:</b> {data[2]}</p>
        <hr style='margin: 20px 0; border: 0; border-top: 1px solid #ccc;'>

        <!-- Career Objective -->
        <h3 style='color: #34495e;'>🎯 Career Objective</h3>
        <p>{data[3]}</p>

        <!-- Skills -->
        <h3 style='color: #34495e;'>🛠 Skills</h3>
        <p>{data[4]}</p>

        <!-- Education -->
        <h3 style='color: #34495e;'>🎓 Education</h3>
        <p>{data[5]}</p>

        <!-- Certifications -->
        <h3 style='color: #34495e;'>📜 Certifications</h3>
        <p>{data[6]}</p>

        <!-- Projects -->
        <h3 style='color: #34495e;'>💡 Projects</h3>
        <p>{data[7]}</p>

        <!-- Experience -->
        <h3 style='color: #34495e;'>💼 Experience</h3>
        <p>{data[8]}</p>

        <!-- Achievements -->
        <h3 style='color: #34495e;'>🏆 Achievements</h3>
        <p>{data[9]}</p>

        <!-- Languages -->
        <h3 style='color: #34495e;'>🌐 Languages</h3>
        <p>{data[10]}</p>

        <!-- Address -->
        <h3 style='color: #34495e;'>📍 Address</h3>
        <p>{data[11]}</p>

    </div>
    """


def generate_resume(msg):
    prompt = f"Generate a resume in HTML format using this info: '{msg}'. Include Name, Skills, Experience, Education."
    res = requests.post(
        "http://localhost:11434/api/generate",
        json={"model": "llama3", "prompt": prompt, "stream": False}
    )
    return res.json()["response"].strip()


def generate_cover_letter(msg):
    prompt = f"Write a cover letter in HTML format based on this info: '{msg}'. Include greeting, intro, skills, and closing."
    res = requests.post(
        "http://localhost:11434/api/generate",
        json={"model": "llama3", "prompt": prompt, "stream": False}
    )
    return res.json()["response"].strip()



@app.route("/download_resume")
def download_resume():
    html = session.get("resume_html")
    if not html:
        return "No resume found in session!", 400

    # Convert HTML → Plain text (simple)
    clean_text = re.sub('<[^<]+?>', '', html)

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    story = [Paragraph(clean_text, styles["Normal"])]

    doc.build(story)
    buffer.seek(0)

    response = make_response(buffer.read())
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = 'attachment; filename=resume.pdf'
    return response




@app.route("/")
def index():
    return render_template("index.html")

@app.route("/admin_login")
def admin_login():
    return render_template("admin_login.html")

@app.route("/admin_login_action",methods=['post'])
def admin_login_action():
    username=request.form.get("username")
    password=request.form.get("password")
    if username==admin_username and password==admin_password:
        session["role"]="admin"
        return redirect("/admin_home")
    else:
        return render_template("main_msg.html", message="Invalid Login Details")

@app.route("/admin_home")
def admin_home():
    return render_template("admin_home.html")

@app.route("/add_employer")
def add_employer():
    employers = list(employer_collection.find())
    return render_template("add_employer.html",    employers= employers )

@app.route("/add_employer_action", methods=["POST"])
def add_employer_action():
    name = request.form.get("name")
    company_name = request.form.get("company_name")
    email = request.form.get("email")
    password = request.form.get("password")
    confirm_password = request.form.get("confirm_password")
    phone = request.form.get("phone")
    address = request.form.get("address")
    city = request.form.get("city")
    state = request.form.get("state")
    zipcode = request.form.get("zipcode")
    dob = request.form.get("dob")

    # ---------- Password Check ----------
    if not password or not confirm_password:
        return render_template("main_msg.html", message="Password fields cannot be empty")

    if password != confirm_password:
        return render_template("main_msg.html", message="Passwords do not match")

    # ---------- Duplicate Email Check ----------
    if employer_collection.count_documents({"email": email}) > 0:
        return render_template("main_msg.html", message="Duplicate Email Address")

    # ---------- Duplicate Phone Check ----------
    if employer_collection.count_documents({"phone": phone}) > 0:
        return render_template("main_msg.html", message="Duplicate Phone Number")

    # ---------- Insert into DB ----------
    employer_data = {
        "name": name,
        "company_name": company_name,
        "email": email,
        "password": password,
        "phone": phone,
        "address": address,
        "city": city,
        "state": state,
        "zipcode": zipcode,
        "dob": dob
    }

    employer_collection.insert_one(employer_data)

    return redirect("/add_employer")

@app.route("/view_employer")
def view_employer():
    query={}
    employer=employer_collection.find(query)
    employers=list(employer)
    return render_template("view_employer.html" ,employers= employers)

@app.route("/remove_employer")
def remove_employer():
    employer_id=request.args.get("employer_id")
    query = {"_id": ObjectId(employer_id)}
    employer_collection.delete_one(query)
    return redirect("/view_employer")

@app.route("/employer_login")
def employer_login():
    return render_template("employer_login.html")

@app.route("/employer_login_action", methods=["POST"])
def employer_login_action():
    email = request.form.get("email")
    password = request.form.get("password")
    count = employer_collection.count_documents({"email": email, "password": password})
    if count>0:
        employer = employer_collection.find_one({"email": email, "password": password})
        session["employer_id"] = str(employer["_id"])
        session["role"] = "employer"
        return redirect("/employer_home")
    else:
        return render_template("employer_message.html", message="Invalid Email or Password")

@app.route("/employer_home")
def employer_home():
    return render_template("employer_home.html")

@app.route("/add_internship")
def add_internship():
    return render_template("add_internship.html")

@app.route("/add_internship_action", methods=['POST'])
def add_internship_action():
    title = request.form.get("title")
    seats = int(request.form.get("seats"))         # NEW FIELD
    start_date = request.form.get("start_date")
    end_date = request.form.get("end_date")
    posted_date = request.form.get("posted_date")
    closing_date = request.form.get("closing_date")
    role = request.form.get("role")
    description = request.form.get("description")

    status = "Pending"
    employer_id = ObjectId(session.get("employer_id"))

    # ---------- Duplicate Check ----------
    duplicate_query = {"title": title, "role": role, "employer_id": employer_id}
    if internship_collection.count_documents(duplicate_query) > 0:
        return render_template(
            "main_msg.html",
            message="Duplicate Internship — Title and Role already exist for this Employer"
        )

    # ---------- Save Internship ----------
    internship_data = {
        "title": title,
        "seats": seats,
        "applied_count": 0,
        "start_date": start_date,
        "end_date": end_date,
        "posted_date": posted_date,
        "closing_date": closing_date,
        "role": role,
        "description": description,
        "status": status,
        "employer_id": employer_id
    }

    internship_collection.insert_one(internship_data)
    return redirect("/view_internships")

@app.route("/view_internships")
def view_internships():
    internships = []
    role = session.get("role")

    # ---------------- EMPLOYER VIEW ----------------
    if role == "employer":
        employer_id = ObjectId(session.get("employer_id"))
        internships = list(internship_collection.find({"employer_id": employer_id}))

        # Add can_apply = False for employer (not needed but safe)
        for i in internships:
            i["can_apply"] = False

    # ---------------- ADMIN VIEW ----------------
    elif role == "admin":
        internships = list(internship_collection.find())

        # Admin can shortlist only (cannot apply)
        for i in internships:
            i["can_apply"] = False

    # ---------------- STUDENT VIEW ----------------
    elif role == "student":
        student_id = session.get("student_id")
        today = datetime.today().date()

        # Search text from search bar
        search_query = request.args.get("search", "").lower()

        # Students see ALL internships (no status filter)
        all_internships = list(internship_collection.find())

        active_internships = []

        for internship in all_internships:
            # Check if internship is active by end date
            end_date = datetime.strptime(internship['end_date'], "%Y-%m-%d").date()

            if today <= end_date:

                # Check if student already applied
                applied = application_collection.find_one({
                    "student_id": ObjectId(student_id),
                    "internship_id": internship["_id"]
                })

                internship['can_apply'] = not bool(applied)
                active_internships.append(internship)

        # Apply search filter
        if search_query:
            internships = [
                i for i in active_internships
                if search_query in i["title"].lower() or search_query in i["role"].lower()
            ]
        else:
            internships = active_internships

    # ---------------- RETURN PAGE ----------------
    return render_template("view_internships.html", internships=internships)

@app.route('/edit_internship')
def edit_internship():
    internship_id = request.args.get('internship_id')
    internship = internship_collection.find_one({'_id': ObjectId(internship_id)})
    return render_template('edit_internship.html', internship=internship)

@app.route("/edit_internship_action", methods=["POST"])
def edit_internship_action():
    internship_id = request.form.get("internship_id")



    updated_data = {
        "title": request.form.get("title"),
        "seats": int(request.form.get("seats")),
        "start_date": request.form.get("start_date"),
        "end_date": request.form.get("end_date"),
        "posted_date": request.form.get("posted_date"),
        "closing_date": request.form.get("closing_date"),
        "role": request.form.get("role"),
        "description": request.form.get("description")
    }

    internship_collection.update_one(
        {"_id": ObjectId(internship_id)},
        {"$set": updated_data}
    )

    return redirect("/view_internships")

@app.route("/student_login")
def student_login():
    return render_template("student_login.html")

@app.route("/student_login_action", methods=["POST"])
def student_login_action():
    email = request.form.get("email")
    password = request.form.get("password")
    student = student_collection.find_one({"email": email, "password": password})
    if student:
        session["student_id"] = str(student["_id"])
        session["role"] = "student"
        return redirect("/student_home")
    else:
        return render_template("main_msg.html", message="Invalid Email or Password")


@app.route("/student_home")
def student_home():
    return render_template("student_home.html")

@app.route("/student_profile")
def student_profile():
    student_id=session["student_id"]
    student = student_collection.find_one({"_id": ObjectId(student_id)})
    return render_template("student_profile.html",student=student)

@app.route("/student_registration")
def student_registration():
    return render_template("student_registration.html")

from werkzeug.utils import secure_filename

@app.route("/student_registration_action", methods=['POST'])
def student_registration_action():

    # Basic fields
    first_name = request.form.get("first_name")
    last_name = request.form.get("last_name")
    email = request.form.get("email")
    phone = request.form.get("phone")
    password = request.form.get("password")
    confirm_password = request.form.get("confirm_password")
    city = request.form.get("city")
    state = request.form.get("state")
    zipcode = request.form.get("zipcode")
    internship_experience = request.form.get("internship_experience")
    typing_speed = request.form.get("typing_speed")

    # LANGUAGES
    languages = request.form.getlist("languages[]")
    # SKILLS
    skills_raw = request.form.get("skills")
    skills = skills_raw.split(",") if skills_raw else []

    # Password Check
    if password != confirm_password:
        return render_template("main_msg.html", message="Password and Confirm Password do not match")

    # Duplicate checks
    if student_collection.count_documents({"email": email}) > 0:
        return render_template("main_msg.html", message="Duplicate Email Address")

    if student_collection.count_documents({"phone": phone}) > 0:
        return render_template("main_msg.html", message="Duplicate Phone Number")


    # ---------- RESUME UPLOAD ----------
    resume = request.files.get("upload_resume")
    if not resume or resume.filename == "":
        return render_template("main_msg.html", message="Resume file is required")

    resume_filename = secure_filename(resume.filename)
    resume_path = PROFILES_PATH + "/" + resume_filename
    resume.save(resume_path)


    # ---------- COVER LETTER UPLOAD ----------
    cover_letter_file = request.files.get("cover_letter")
    if not cover_letter_file or cover_letter_file.filename == "":
        return render_template("main_msg.html", message="Cover Letter file is required")

    cover_filename = secure_filename(cover_letter_file.filename)
    cover_letter_path = PROFILES_PATH + "/" + cover_filename
    cover_letter_file.save(cover_letter_path)


    # ---------- SAVE TO MONGO ----------
    data = {
        "first_name": first_name,
        "last_name": last_name,
        "email": email,
        "phone": phone,
        "password": password,
        "resume": resume_filename,
        "cover_letter": cover_filename,
        "city": city,
        "state": state,
        "zipcode": zipcode,
        "internship_experience": internship_experience,
        "languages": languages,
        "typing_speed": typing_speed,
        "skills": skills
    }

    student_collection.insert_one(data)

    return render_template("main_msg.html", message="Student Registration Successful")

@app.route("/apply_internship")
def apply_internship():
    internship_id = request.args.get("internship_id")
    employer_id = request.args.get("employer_id")
    student_id = session.get("student_id")

    # Check if already applied
    already_applied = application_collection.find_one({
        "internship_id": ObjectId(internship_id),
        "student_id": ObjectId(student_id)
    })
    if already_applied:
        return render_template(
            "student_message.html",
            message="You have already applied for this internship."
        )

    # Save new application
    application = {
        "internship_id": ObjectId(internship_id),
        "employer_id": ObjectId(employer_id),
        "student_id": ObjectId(student_id),
        "applied_date": datetime.now(),
        "status": "Applied"
    }

    application_collection.insert_one(application)

    # ✅ UPDATE applied count in internships collection
    internship_collection.updateF_one(
        {"_id": ObjectId(internship_id)},
        {"$inc": {"applied_count": 1}}
    )

    return render_template(
        "student_message.html",
        message="Internship Applied Successfully"
    )


@app.route("/view_applications")
def view_applications():
    role = session.get("role")
    if role == "admin":
        applications = list(application_collection.find())
    elif role == "employer":
        employer_id = ObjectId(session.get("employer_id"))
        applications = list(application_collection.find({"employer_id": employer_id}))
    elif role == "student":
        student_id = ObjectId(session.get("student_id"))
        applications = list(application_collection.find({"student_id": student_id}))
    else:
        applications = []
    for application in applications:
        application['employer'] = employer_collection.find_one({"_id": ObjectId(application['employer_id'])})
        application['student'] = student_collection.find_one({"_id": ObjectId(application['student_id'])})
        application['internship'] = internship_collection.find_one({"_id": ObjectId(application['internship_id'])})
    return render_template("view_applications.html", applications=applications,get_employer_name_by_employer_id=get_employer_name_by_employer_id,get_internship_title_by_id=get_internship_title_by_id, get_student_name_by_student_id=get_student_name_by_student_id)

def get_employer_name_by_employer_id(employer_id):
    employer = employer_collection.find_one({"_id": ObjectId(employer_id)})
    return employer

def get_student_name_by_student_id(student_id):
    student = student_collection.find_one({"_id": ObjectId(student_id)})
    if student:
        return f"{student.get('first_name', '')} {student.get('last_name', '')}"

def get_internship_title_by_id(internship_id):
    print(internship_id)
    internship = internship_collection.find_one({"_id": ObjectId(internship_id)})
    return internship


@app.route("/accept_application")
def accept_application():
    application_id = request.args.get("application_id")
    application = application_collection.find_one({"_id":ObjectId(application_id)})
    internship_id = application['internship_id']
    internship = internship_collection.find_one({"_id":ObjectId(internship_id)})
    count = application_collection.count_documents({"internship_id":ObjectId(internship_id),"status":"Shortlisted"})
    if application_id:
        application_collection.update_one(
            {"_id": ObjectId(application_id)},
            {"$set": {"status": "Accepted"}}
        )

    return redirect("/view_applications")


@app.route("/reject_application")
def reject_application():
    application_id = request.args.get("application_id")
    if application_id:
        application_collection.update_one(
            {"_id": ObjectId(application_id)},
            {"$set": {"status": "Rejected"}}
        )

    return redirect("/view_applications")

@app.route("/cancel_application/<application_id>")
def cancel_application(application_id):
    application_collection.delete_one({"_id": ObjectId(application_id)})
    return redirect("/view_applications")



@app.route("/shortlist_candidate")
def shortlist_candidate():
    internship_id = request.args.get("internship_id")

    query = {"internship_id": ObjectId(internship_id)}
    shortlists = list(shortlist_collection.find(query))

    return render_template(
        "shortlist_candidate.html",
        shortlists=shortlists,
        get_student_name_by_student_id=get_student_name_by_student_id,
        get_company_name_by_employer_id=get_company_name_by_employer_id,
        get_internship_title_by_id=get_internship_title_by_id


    )

def student_name_by_student_id(student_id):
    student = student_collection.find_one({"_id": ObjectId(student_id)})
    return student["first_name"]

def get_company_name_by_employer_id(employer_id):
    employer = employer_collection.find_one({"_id": ObjectId(employer_id)})
    if employer:
        return employer.get("company_name")
    return None


def get_internship_title_by_id(internship_id):

    internship = internship_collection.find_one({"_id": ObjectId(internship_id)})
    return internship




@app.route("/mark_selected")
def mark_selected():
    student_id = request.args.get("student_id")
    application_id = request.args.get("application_id")
    internship_id = request.args.get("internship_id")

    employer_id = session.get("employer_id")
    application = application_collection.find_one({"_id":ObjectId(application_id)})
    internship_id = application['internship_id']
    internship = internship_collection.find_one({"_id":ObjectId(internship_id)})
    count = application_collection.count_documents({"internship_id":ObjectId(internship_id),"status":"Shortlisted"})
    seats = int(internship['seats'])
    if count>=seats:
        return render_template("employer_message.html",message="Positions Filled")


    application_collection.update_one(
        {"_id": ObjectId(application_id)},
        {"$set": {"status": "Shortlisted"}}
    )


    shortlist_doc = {
        "application_id": ObjectId(application_id),
        "student_id": ObjectId(student_id),
        "internship_id": ObjectId(internship_id),
        "employer_id": ObjectId(employer_id),
        "date": datetime.now(),
        "status": "Shortlisted"
    }

    shortlist_collection.insert_one(shortlist_doc)

    return redirect("/view_applications")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


# show details of Python Developer
# Show my applications
# who offers Python Developer?
# show internships for Python

# show internships at gvs

app.run(debug=True)